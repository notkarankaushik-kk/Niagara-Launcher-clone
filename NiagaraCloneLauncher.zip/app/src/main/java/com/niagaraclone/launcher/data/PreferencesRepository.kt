package com.niagaraclone.launcher.data

import android.content.Context
import androidx.datastore.core.DataStore
import androidx.datastore.preferences.core.Preferences
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.core.stringSetPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map

private val Context.launcherDataStore: DataStore<Preferences> by preferencesDataStore(
    name = "niagara_clone_preferences"
)

class PreferencesRepository(private val context: Context) {

    companion object {
        private val FAVORITES_ORDERED_KEY = stringPreferencesKey("favorites_ordered")
        private val HIDDEN_PACKAGES_KEY = stringSetPreferencesKey("hidden_packages")
        const val MAX_FAVORITES = 8
        private const val DELIMITER = "|"
    }

    val favoritePackagesFlow: Flow<List<String>> = context.launcherDataStore.data.map { prefs ->
        val raw = prefs[FAVORITES_ORDERED_KEY].orEmpty()
        if (raw.isBlank()) {
            emptyList()
        } else {
            raw.split(DELIMITER).filter { it.isNotBlank() }.distinct().take(MAX_FAVORITES)
        }
    }

    val hiddenPackagesFlow: Flow<Set<String>> = context.launcherDataStore.data.map { prefs ->
        prefs[HIDDEN_PACKAGES_KEY] ?: emptySet()
    }

    suspend fun toggleFavorite(packageName: String): Boolean {
        var added = false
        context.launcherDataStore.edit { prefs ->
            val current = prefs[FAVORITES_ORDERED_KEY]
                .orEmpty()
                .split(DELIMITER)
                .filter { it.isNotBlank() }
                .toMutableList()

            if (current.contains(packageName)) {
                current.remove(packageName)
                added = false
            } else {
                if (current.size >= MAX_FAVORITES) {
                    current.removeAt(current.lastIndex)
                }
                current.add(packageName)
                added = true
            }
            prefs[FAVORITES_ORDERED_KEY] = current.joinToString(DELIMITER)
        }
        return added
    }

    suspend fun seedDefaultFavoritesIfEmpty(defaultPackages: List<String>) {
        context.launcherDataStore.edit { prefs ->
            if (prefs[FAVORITES_ORDERED_KEY] == null && defaultPackages.isNotEmpty()) {
                prefs[FAVORITES_ORDERED_KEY] = defaultPackages.take(MAX_FAVORITES).joinToString(DELIMITER)
            }
        }
    }

    suspend fun toggleHidden(packageName: String) {
        context.launcherDataStore.edit { prefs ->
            val hidden = (prefs[HIDDEN_PACKAGES_KEY] ?: emptySet()).toMutableSet()
            if (hidden.contains(packageName)) {
                hidden.remove(packageName)
            } else {
                hidden.add(packageName)
                // Also unpin from favorites if hidden
                val currentFavs = prefs[FAVORITES_ORDERED_KEY]
                    .orEmpty()
                    .split(DELIMITER)
                    .filter { it.isNotBlank() && it != packageName }
                prefs[FAVORITES_ORDERED_KEY] = currentFavs.joinToString(DELIMITER)
            }
            prefs[HIDDEN_PACKAGES_KEY] = hidden
        }
    }

    suspend fun clearAllHidden() {
        context.launcherDataStore.edit { prefs ->
            prefs[HIDDEN_PACKAGES_KEY] = emptySet()
        }
    }
}
