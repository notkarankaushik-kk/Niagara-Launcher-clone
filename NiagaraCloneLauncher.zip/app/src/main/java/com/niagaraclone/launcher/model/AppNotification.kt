package com.niagaraclone.launcher.model

import android.app.PendingIntent
import androidx.compose.runtime.Immutable

@Immutable
data class AppNotification(
    val key: String,
    val packageName: String,
    val title: String,
    val text: String,
    val timestamp: Long,
    val contentIntent: PendingIntent?
)
