package com.niagaraclone.launcher.service

import android.app.Notification
import android.service.notification.NotificationListenerService
import android.service.notification.StatusBarNotification
import com.niagaraclone.launcher.model.AppNotification
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import java.lang.ref.WeakReference

class LauncherNotificationService : NotificationListenerService() {

    companion object {
        private val _notificationsByPackage = MutableStateFlow<Map<String, AppNotification>>(emptyMap())
        val notificationsByPackage: StateFlow<Map<String, AppNotification>> = _notificationsByPackage.asStateFlow()

        private val _isConnected = MutableStateFlow(false)
        val isConnected: StateFlow<Boolean> = _isConnected.asStateFlow()

        private var instanceRef: WeakReference<LauncherNotificationService>? = null

        fun dismissNotification(key: String, packageName: String) {
            // Immediately remove from UI state for responsive swipe-to-dismiss UX
            _notificationsByPackage.value = _notificationsByPackage.value.toMutableMap().apply {
                remove(packageName)
            }
            try {
                instanceRef?.get()?.cancelNotification(key)
            } catch (_: Exception) {
                // Ignore security or binder exceptions if listener disconnected
            }
        }
    }

    override fun onListenerConnected() {
        super.onListenerConnected()
        instanceRef = WeakReference(this)
        _isConnected.value = true
        refreshActiveNotifications()
    }

    override fun onListenerDisconnected() {
        super.onListenerDisconnected()
        _isConnected.value = false
        if (instanceRef?.get() === this) {
            instanceRef = null
        }
    }

    override fun onNotificationPosted(sbn: StatusBarNotification?) {
        refreshActiveNotifications()
    }

    override fun onNotificationRemoved(sbn: StatusBarNotification?) {
        refreshActiveNotifications()
    }

    private fun refreshActiveNotifications() {
        val currentList = try {
            activeNotifications ?: emptyArray()
        } catch (_: Exception) {
            emptyArray()
        }

        val mapped = mutableMapOf<String, AppNotification>()

        for (sbn in currentList) {
            val notification = sbn.notification ?: continue
            val flags = notification.flags

            // Filter out ongoing system / foreground service notifications
            val isOngoing = (flags and Notification.FLAG_ONGOING_EVENT) != 0
            val isForeground = (flags and Notification.FLAG_FOREGROUND_SERVICE) != 0
            val isGroupSummary = (flags and Notification.FLAG_GROUP_SUMMARY) != 0
            if (isOngoing || isForeground || isGroupSummary) continue

            val extras = notification.extras ?: continue
            val rawTitle = extras.getCharSequence(Notification.EXTRA_TITLE)?.toString()?.trim().orEmpty()
            val rawText = (
                extras.getCharSequence(Notification.EXTRA_TEXT)
                    ?: extras.getCharSequence(Notification.EXTRA_BIG_TEXT)
                )?.toString()?.trim().orEmpty()

            if (rawTitle.isEmpty() && rawText.isEmpty()) continue

            val existing = mapped[sbn.packageName]
            if (existing == null || sbn.postTime >= existing.timestamp) {
                mapped[sbn.packageName] = AppNotification(
                    key = sbn.key,
                    packageName = sbn.packageName,
                    title = rawTitle,
                    text = rawText.replace("\n", " "),
                    timestamp = sbn.postTime,
                    contentIntent = notification.contentIntent
                )
            }
        }

        _notificationsByPackage.value = mapped
    }
}
