package com.niagaraclone.launcher.ui.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

private val NiagaraDarkColors = darkColorScheme(
    primary = Color(0xFF7DD3FC),
    onPrimary = Color(0xFF082F49),
    secondary = Color(0xFFA5F3FC),
    onSecondary = Color(0xFF083344),
    tertiary = Color(0xFFFDE047),
    background = Color.Transparent,
    surface = Color(0xCC111827),
    onSurface = Color(0xFFF8FAFC),
    surfaceVariant = Color(0xE61E293B),
    onSurfaceVariant = Color(0xFFCBD5E1)
)

@Composable
fun NiagaraCloneTheme(content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = NiagaraDarkColors,
        content = content
    )
}
