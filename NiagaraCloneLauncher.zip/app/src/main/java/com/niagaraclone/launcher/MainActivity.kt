package com.niagaraclone.launcher

import android.content.Intent
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.viewModels
import com.niagaraclone.launcher.ui.LauncherScreen
import com.niagaraclone.launcher.ui.theme.NiagaraCloneTheme
import com.niagaraclone.launcher.viewmodel.LauncherViewModel

class MainActivity : ComponentActivity() {

    private val launcherViewModel: LauncherViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()

        setContent {
            NiagaraCloneTheme {
                LauncherScreen(viewModel = launcherViewModel)
            }
        }
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        // Pressing the Home button while already in the launcher returns to Favorites & closes search
        if (intent.action == Intent.ACTION_MAIN && intent.hasCategory(Intent.CATEGORY_HOME)) {
            launcherViewModel.setSearchOverlayVisible(false)
            launcherViewModel.setAllAppsMode(false)
        }
    }
}
