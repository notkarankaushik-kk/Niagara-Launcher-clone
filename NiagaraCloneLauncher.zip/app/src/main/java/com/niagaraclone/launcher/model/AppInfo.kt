package com.niagaraclone.launcher.model

import android.content.ComponentName
import androidx.compose.runtime.Immutable
import androidx.compose.ui.graphics.ImageBitmap

@Immutable
data class AppInfo(
    val label: String,
    val packageName: String,
    val activityName: String,
    val icon: ImageBitmap,
    val firstLetter: Char,
    val isFavorite: Boolean = false,
    val isHidden: Boolean = false,
    val notification: AppNotification? = null
) {
    val componentName: ComponentName
        get() = ComponentName(packageName, activityName)
}
