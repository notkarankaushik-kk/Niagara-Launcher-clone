package com.niagaraclone.launcher.viewmodel

import android.app.Application
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.drawable.BitmapDrawable
import android.graphics.drawable.Drawable
import android.net.Uri
import android.os.Build
import android.provider.Settings
import androidx.compose.runtime.Immutable
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.asImageBitmap
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.niagaraclone.launcher.data.PreferencesRepository
import com.niagaraclone.launcher.model.AppInfo
import com.niagaraclone.launcher.model.AppNotification
import com.niagaraclone.launcher.service.LauncherNotificationService
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.util.Locale

@Immutable
data class LauncherUiState(
    val favoriteApps: List<AppInfo> = emptyList(),
    val allVisibleApps: List<AppInfo> = emptyList(),
    val hiddenApps: List<AppInfo> = emptyList(),
    val searchResults: List<AppInfo> = emptyList(),
    val searchQuery: String = "",
    val isSearchOverlayOpen: Boolean = false,
    val isAllAppsMode: Boolean = false,
    val activeScrollLetter: Char? = null,
    val availableLetters: List<Char> = ALPHABET_CHARS,
    val letterStartIndexMap: Map<Char, Int> = emptyMap(),
    val isNotificationAccessGranted: Boolean = false,
    val isLoading: Boolean = true
) {
    companion object {
        val ALPHABET_CHARS: List<Char> = listOf('#') + ('A'..'Z').toList()
    }
}

class LauncherViewModel(application: Application) : AndroidViewModel(application) {

    private val appContext: Context = application.applicationContext
    private val preferencesRepository = PreferencesRepository(appContext)

    private val rawInstalledApps = MutableStateFlow<List<AppInfo>>(emptyList())
    private val searchQueryFlow = MutableStateFlow("")
    private val isSearchOverlayOpenFlow = MutableStateFlow(false)
    private val isAllAppsModeFlow = MutableStateFlow(false)
    private val activeScrollLetterFlow = MutableStateFlow<Char?>(null)
    private val isLoadingFlow = MutableStateFlow(true)

    private val packageChangeReceiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context?, intent: Intent?) {
            refreshInstalledApps()
        }
    }

    init {
        registerPackageReceiver()
        refreshInstalledApps()
    }

    val uiState: StateFlow<LauncherUiState> = combine(
        rawInstalledApps,
        preferencesRepository.favoritePackagesFlow,
        preferencesRepository.hiddenPackagesFlow,
        LauncherNotificationService.notificationsByPackage,
        LauncherNotificationService.isConnected,
        searchQueryFlow,
        isSearchOverlayOpenFlow,
        isAllAppsModeFlow,
        activeScrollLetterFlow,
        isLoadingFlow
    ) { values ->
        @Suppress("UNCHECKED_CAST")
        val installed = values[0] as List<AppInfo>
        @Suppress("UNCHECKED_CAST")
        val favoritePackages = values[1] as List<String>
        @Suppress("UNCHECKED_CAST")
        val hiddenPackages = values[2] as Set<String>
        @Suppress("UNCHECKED_CAST")
        val notifications = values[3] as Map<String, AppNotification>
        val notificationConnected = values[4] as Boolean
        val query = values[5] as String
        val searchOpen = values[6] as Boolean
        val allAppsMode = values[7] as Boolean
        val activeLetter = values[8] as Char?
        val loading = values[9] as Boolean

        val favoriteSet = favoritePackages.toSet()

        val enriched = installed.map { app ->
            app.copy(
                isFavorite = favoriteSet.contains(app.packageName),
                isHidden = hiddenPackages.contains(app.packageName),
                notification = notifications[app.packageName]
            )
        }

        val visibleApps = enriched
            .filter { !it.isHidden }
            .sortedBy { it.label.lowercase(Locale.getDefault()) }

        val hiddenAppsList = enriched
            .filter { it.isHidden }
            .sortedBy { it.label.lowercase(Locale.getDefault()) }

        val byPkg = visibleApps.associateBy { it.packageName }
        val orderedFavorites = favoritePackages.mapNotNull { byPkg[it] }

        // Build index map for each letter in theLazyColumn
        // Note: index 0 in the main LazyColumn is the Header/Favorites section, so app items start at index 1
        val letterMap = mutableMapOf<Char, Int>()
        visibleApps.forEachIndexed { idx, app ->
            letterMap.putIfAbsent(app.firstLetter, idx + 1)
        }

        val filteredSearch = if (query.isBlank()) {
            visibleApps.take(12)
        } else {
            visibleApps
                .mapNotNull { app ->
                    val score = fuzzyMatchScore(app.label, query)
                    if (score > 0) app to score else null
                }
                .sortedWith(
                    compareByDescending<Pair<AppInfo, Int>> { it.second }
                        .thenBy { it.first.label.lowercase(Locale.getDefault()) }
                )
                .map { it.first }
        }

        LauncherUiState(
            favoriteApps = orderedFavorites,
            allVisibleApps = visibleApps,
            hiddenApps = hiddenAppsList,
            searchResults = filteredSearch,
            searchQuery = query,
            isSearchOverlayOpen = searchOpen,
            isAllAppsMode = allAppsMode,
            activeScrollLetter = activeLetter,
            availableLetters = LauncherUiState.ALPHABET_CHARS,
            letterStartIndexMap = letterMap,
            isNotificationAccessGranted = notificationConnected || isNotificationServiceEnabled(appContext),
            isLoading = loading
        )
    }.stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(5_000),
        initialValue = LauncherUiState()
    )

    private fun registerPackageReceiver() {
        val filter = IntentFilter().apply {
            addAction(Intent.ACTION_PACKAGE_ADDED)
            addAction(Intent.ACTION_PACKAGE_REMOVED)
            addAction(Intent.ACTION_PACKAGE_REPLACED)
            addAction(Intent.ACTION_PACKAGE_CHANGED)
            addDataScheme("package")
        }
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            appContext.registerReceiver(packageChangeReceiver, filter, Context.RECEIVER_EXPORTED)
        } else {
            appContext.registerReceiver(packageChangeReceiver, filter)
        }
    }

    fun refreshInstalledApps() {
        viewModelScope.launch {
            isLoadingFlow.value = true
            val loaded = withContext(Dispatchers.IO) {
                queryLaunchableApps(appContext.packageManager, appContext.packageName)
            }
            rawInstalledApps.value = loaded
            if (loaded.isNotEmpty()) {
                preferencesRepository.seedDefaultFavoritesIfEmpty(
                    loaded.take(6).map { it.packageName }
                )
            }
            isLoadingFlow.value = false
        }
    }

    private fun queryLaunchableApps(
        pm: PackageManager,
        ownPackageName: String
    ): List<AppInfo> {
        val mainIntent = Intent(Intent.ACTION_MAIN, null).apply {
            addCategory(Intent.CATEGORY_LAUNCHER)
        }

        val resolveInfos = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            pm.queryIntentActivities(mainIntent, PackageManager.ResolveInfoFlags.of(0L))
        } else {
            @Suppress("DEPRECATION")
            pm.queryIntentActivities(mainIntent, 0)
        }

        return resolveInfos
            .asSequence()
            .mapNotNull { info ->
                val activityInfo = info.activityInfo ?: return@mapNotNull null
                val pkg = activityInfo.packageName ?: return@mapNotNull null
                if (pkg == ownPackageName) return@mapNotNull null

                val label = info.loadLabel(pm)?.toString()?.trim().takeUnless { it.isNullOrEmpty() }
                    ?: pkg
                val drawable = try {
                    info.loadIcon(pm)
                } catch (_: Exception) {
                    pm.defaultActivityIcon
                }
                val bitmap = drawableToImageBitmap(drawable)
                val firstChar = label.firstOrNull()?.uppercaseChar() ?: '#'
                val bucket = if (firstChar in 'A'..'Z') firstChar else '#'

                AppInfo(
                    label = label,
                    packageName = pkg,
                    activityName = activityInfo.name,
                    icon = bitmap,
                    firstLetter = bucket
                )
            }
            .distinctBy { it.packageName }
            .sortedBy { it.label.lowercase(Locale.getDefault()) }
            .toList()
    }

    private fun drawableToImageBitmap(drawable: Drawable, targetSizePx: Int = 128): ImageBitmap {
        if (drawable is BitmapDrawable && drawable.bitmap != null) {
            return drawable.bitmap.asImageBitmap()
        }
        val width = if (drawable.intrinsicWidth > 0) drawable.intrinsicWidth else targetSizePx
        val height = if (drawable.intrinsicHeight > 0) drawable.intrinsicHeight else targetSizePx
        val bmp = Bitmap.createBitmap(
            width.coerceAtMost(targetSizePx),
            height.coerceAtMost(targetSizePx),
            Bitmap.Config.ARGB_8888
        )
        val canvas = Canvas(bmp)
        drawable.setBounds(0, 0, canvas.width, canvas.height)
        drawable.draw(canvas)
        return bmp.asImageBitmap()
    }

    private fun fuzzyMatchScore(label: String, rawQuery: String): Int {
        val query = rawQuery.trim().lowercase(Locale.getDefault())
        if (query.isEmpty()) return 1
        val target = label.lowercase(Locale.getDefault())

        // Exact prefix match gets highest score
        if (target.startsWith(query)) return 1000 - target.length

        // Word-boundary prefix match (e.g., "play" in "Google Play Store")
        val words = target.split(" ", "-", "_", ".")
        if (words.any { it.startsWith(query) }) return 800 - target.length

        // Acronym match (e.g., "yt" or "gps")
        val initials = words.mapNotNull { it.firstOrNull() }.joinToString("")
        if (initials.startsWith(query)) return 750

        // Substring match
        val containsIdx = target.indexOf(query)
        if (containsIdx >= 0) return 600 - containsIdx * 5

        // Ordered subsequence fuzzy match
        var qIdx = 0
        var consecutiveBonus = 0
        var lastMatchIdx = -2
        for (i in target.indices) {
            if (qIdx < query.length && target[i] == query[qIdx]) {
                if (i == lastMatchIdx + 1) consecutiveBonus += 25
                lastMatchIdx = i
                qIdx++
            }
        }
        return if (qIdx == query.length) {
            250 + consecutiveBonus - target.length
        } else {
            0
        }
    }

    private fun isNotificationServiceEnabled(context: Context): Boolean {
        val enabledListeners = Settings.Secure.getString(
            context.contentResolver,
            "enabled_notification_listeners"
        ).orEmpty()
        return enabledListeners.contains(context.packageName)
    }

    fun launchApp(app: AppInfo) {
        try {
            val launchIntent = appContext.packageManager.getLaunchIntentForPackage(app.packageName)
                ?: Intent(Intent.ACTION_MAIN).apply {
                    addCategory(Intent.CATEGORY_LAUNCHER)
                    component = app.componentName
                }
            launchIntent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_RESET_TASK_IF_NEEDED)
            appContext.startActivity(launchIntent)
            setSearchOverlayVisible(false)
        } catch (_: Exception) {
            // Ignore launch failures for disabled packages
        }
    }

    fun openNotification(notification: AppNotification, fallbackApp: AppInfo) {
        val pending = notification.contentIntent
        if (pending != null) {
            try {
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.UPSIDE_DOWN_CAKE) {
                    val options = android.app.ActivityOptions.makeBasic()
                        .setPendingIntentBackgroundActivityStartMode(
                            android.app.ActivityOptions.MODE_BACKGROUND_ACTIVITY_START_ALLOWED
                        )
                        .toBundle()
                    pending.send(appContext, 0, null, null, null, null, options)
                } else {
                    pending.send()
                }
                LauncherNotificationService.dismissNotification(notification.key, notification.packageName)
                return
            } catch (_: Exception) {
                // Fall back to launching the app
            }
        }
        launchApp(fallbackApp)
    }

    fun dismissNotification(notification: AppNotification) {
        LauncherNotificationService.dismissNotification(notification.key, notification.packageName)
    }

    fun toggleFavorite(packageName: String) {
        viewModelScope.launch {
            preferencesRepository.toggleFavorite(packageName)
        }
    }

    fun toggleHidden(packageName: String) {
        viewModelScope.launch {
            preferencesRepository.toggleHidden(packageName)
        }
    }

    fun unhideAllApps() {
        viewModelScope.launch {
            preferencesRepository.clearAllHidden()
        }
    }

    fun openAppInfo(packageName: String) {
        try {
            val intent = Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS).apply {
                data = Uri.fromParts("package", packageName, null)
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            }
            appContext.startActivity(intent)
        } catch (_: Exception) {
        }
    }

    fun requestUninstall(packageName: String) {
        try {
            val intent = Intent(Intent.ACTION_DELETE).apply {
                data = Uri.fromParts("package", packageName, null)
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            }
            appContext.startActivity(intent)
        } catch (_: Exception) {
        }
    }

    fun openNotificationListenerSettings() {
        try {
            val intent = Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS).apply {
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            }
            appContext.startActivity(intent)
        } catch (_: Exception) {
        }
    }

    fun openSystemDefaultLauncherSettings() {
        try {
            val intent = Intent(Settings.ACTION_HOME_SETTINGS).apply {
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            }
            appContext.startActivity(intent)
        } catch (_: Exception) {
        }
    }

    fun setSearchQuery(query: String) {
        searchQueryFlow.value = query
    }

    fun setSearchOverlayVisible(visible: Boolean) {
        isSearchOverlayOpenFlow.value = visible
        if (!visible) {
            searchQueryFlow.value = ""
        }
    }

    fun setAllAppsMode(allApps: Boolean) {
        isAllAppsModeFlow.value = allApps
    }

    fun setActiveScrollLetter(letter: Char?) {
        activeScrollLetterFlow.value = letter
        if (letter != null) {
            isAllAppsModeFlow.value = true
        }
    }

    override fun onCleared() {
        super.onCleared()
        try {
            appContext.unregisterReceiver(packageChangeReceiver)
        } catch (_: Exception) {
        }
    }
}
