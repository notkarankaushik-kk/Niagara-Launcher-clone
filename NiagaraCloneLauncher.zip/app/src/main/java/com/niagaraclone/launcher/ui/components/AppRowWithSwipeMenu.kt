package com.niagaraclone.launcher.ui.components

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.spring
import androidx.compose.animation.expandVertically
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.shrinkVertically
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.gestures.detectHorizontalDragGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.Close
import androidx.compose.material.icons.outlined.DeleteOutline
import androidx.compose.material.icons.outlined.Info
import androidx.compose.material.icons.outlined.PushPin
import androidx.compose.material.icons.outlined.VisibilityOff
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Shadow
import androidx.compose.ui.hapticfeedback.HapticFeedbackType
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalHapticFeedback
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.niagaraclone.launcher.model.AppInfo
import com.niagaraclone.launcher.model.AppNotification
import kotlinx.coroutines.launch
import kotlin.math.roundToInt

@OptIn(ExperimentalFoundationApi::class)
@Composable
fun AppRowWithSwipeMenu(
    app: AppInfo,
    onLaunchApp: (AppInfo) -> Unit,
    onOpenNotification: (AppNotification, AppInfo) -> Unit,
    onDismissNotification: (AppNotification) -> Unit,
    onToggleFavorite: (String) -> Unit,
    onToggleHidden: (String) -> Unit,
    onOpenAppInfo: (String) -> Unit,
    onRequestUninstall: (String) -> Unit,
    modifier: Modifier = Modifier
) {
    val scope = rememberCoroutineScope()
    val haptic = LocalHapticFeedback.current
    val rowOffsetX = remember { Animatable(0f) }
    var isActionMenuExpanded by remember { mutableStateOf(false) }

    val textShadow = Shadow(
        color = Color.Black.copy(alpha = 0.65f),
        offset = Offset(0f, 2f),
        blurRadius = 6f
    )

    Column(
        modifier = modifier
            .fillMaxWidth()
            .padding(start = 24.dp, end = 48.dp, top = 4.dp, bottom = 4.dp)
    ) {
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .offset { IntOffset(rowOffsetX.value.roundToInt(), 0) }
                .clip(RoundedCornerShape(18.dp))
                .combinedClickable(
                    onClick = {
                        if (isActionMenuExpanded) {
                            isActionMenuExpanded = false
                        } else {
                            onLaunchApp(app)
                        }
                    },
                    onLongClick = {
                        haptic.performHapticFeedback(HapticFeedbackType.LongPress)
                        isActionMenuExpanded = !isActionMenuExpanded
                    }
                )
                .pointerInput(app.packageName) {
                    var triggeredInDrag = false
                    detectHorizontalDragGestures(
                        onDragStart = { triggeredInDrag = false },
                        onHorizontalDrag = { change, dragAmount ->
                            if (dragAmount > 0f || rowOffsetX.value > 0f) {
                                change.consume()
                                val nextOffset = (rowOffsetX.value + dragAmount * 0.65f).coerceIn(0f, 160f)
                                scope.launch { rowOffsetX.snapTo(nextOffset) }
                                if (!triggeredInDrag && nextOffset >= 96f) {
                                    triggeredInDrag = true
                                    haptic.performHapticFeedback(HapticFeedbackType.TextHandleMove)
                                    isActionMenuExpanded = !isActionMenuExpanded
                                }
                            }
                        },
                        onDragEnd = {
                            scope.launch {
                                rowOffsetX.animateTo(
                                    targetValue = 0f,
                                    animationSpec = spring(
                                        dampingRatio = Spring.DampingRatioMediumBouncy,
                                        stiffness = Spring.StiffnessMedium
                                    )
                                )
                            }
                        },
                        onDragCancel = {
                            scope.launch {
                                rowOffsetX.animateTo(0f)
                            }
                        }
                    )
                }
                .padding(vertical = 8.dp, horizontal = 6.dp)
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                modifier = Modifier.fillMaxWidth()
            ) {
                Image(
                    bitmap = app.icon,
                    contentDescription = app.label,
                    modifier = Modifier
                        .size(42.dp)
                        .clip(CircleShape)
                )

                Spacer(modifier = Modifier.width(16.dp))

                Column(modifier = Modifier.weight(1f)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text(
                            text = app.label,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis,
                            style = TextStyle(
                                color = Color.White,
                                fontSize = 18.sp,
                                fontWeight = FontWeight.Medium,
                                shadow = textShadow
                            )
                        )
                        if (app.isFavorite) {
                            Spacer(modifier = Modifier.width(6.dp))
                            Box(
                                modifier = Modifier
                                    .size(6.dp)
                                    .clip(CircleShape)
                                    .background(MaterialTheme.colorScheme.primary)
                            )
                        }
                    }

                    // Inline single-line notification preview with tap-to-open & horizontal swipe-to-dismiss
                    val notif = app.notification
                    if (notif != null) {
                        Spacer(modifier = Modifier.height(3.dp))
                        InlineNotificationPreviewRow(
                            notification = notif,
                            onTap = { onOpenNotification(notif, app) },
                            onDismiss = { onDismissNotification(notif) }
                        )
                    }
                }
            }
        }

        // Swipe-Right / Long-Press Spring-Animated Action Menu Card
        AnimatedVisibility(
            visible = isActionMenuExpanded,
            enter = expandVertically(
                animationSpec = spring(
                    dampingRatio = Spring.DampingRatioMediumBouncy,
                    stiffness = Spring.StiffnessMediumLow
                )
            ) + fadeIn(),
            exit = shrinkVertically() + fadeOut()
        ) {
            Surface(
                shape = RoundedCornerShape(20.dp),
                color = MaterialTheme.colorScheme.surfaceVariant,
                tonalElevation = 8.dp,
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(top = 4.dp, bottom = 6.dp)
            ) {
                Column(modifier = Modifier.padding(12.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = app.label,
                            color = Color.White,
                            fontWeight = FontWeight.SemiBold,
                            fontSize = 14.sp,
                            modifier = Modifier.padding(start = 8.dp)
                        )
                        IconButton(
                            onClick = { isActionMenuExpanded = false },
                            modifier = Modifier.size(28.dp)
                        ) {
                            Icon(
                                imageVector = Icons.Outlined.Close,
                                contentDescription = "Close Menu",
                                tint = Color.White.copy(alpha = 0.7f),
                                modifier = Modifier.size(16.dp)
                            )
                        }
                    }

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceEvenly
                    ) {
                        PopupMenuActionButton(
                            icon = Icons.Outlined.PushPin,
                            label = if (app.isFavorite) "Unpin" else "Pin Fav",
                            onClick = {
                                onToggleFavorite(app.packageName)
                                isActionMenuExpanded = false
                            }
                        )
                        PopupMenuActionButton(
                            icon = Icons.Outlined.VisibilityOff,
                            label = if (app.isHidden) "Unhide" else "Hide App",
                            onClick = {
                                onToggleHidden(app.packageName)
                                isActionMenuExpanded = false
                            }
                        )
                        PopupMenuActionButton(
                            icon = Icons.Outlined.Info,
                            label = "App Info",
                            onClick = {
                                onOpenAppInfo(app.packageName)
                                isActionMenuExpanded = false
                            }
                        )
                        PopupMenuActionButton(
                            icon = Icons.Outlined.DeleteOutline,
                            label = "Uninstall",
                            tint = Color(0xFFFCA5A5),
                            onClick = {
                                onRequestUninstall(app.packageName)
                                isActionMenuExpanded = false
                            }
                        )
                    }
                }
            }
        }
    }
}

@Composable
private fun InlineNotificationPreviewRow(
    notification: AppNotification,
    onTap: () -> Unit,
    onDismiss: () -> Unit
) {
    val scope = rememberCoroutineScope()
    val dismissOffsetX = remember { Animatable(0f) }
    val haptic = LocalHapticFeedback.current

    val combinedLine = remember(notification.title, notification.text) {
        when {
            notification.title.isNotBlank() && notification.text.isNotBlank() ->
                "${notification.title}: ${notification.text}"
            notification.title.isNotBlank() -> notification.title
            else -> notification.text
        }
    }

    Surface(
        shape = RoundedCornerShape(10.dp),
        color = Color.Black.copy(alpha = 0.42f),
        modifier = Modifier
            .offset { IntOffset(dismissOffsetX.value.roundToInt(), 0) }
            .clickable(onClick = onTap)
            .pointerInput(notification.key) {
                detectHorizontalDragGestures(
                    onHorizontalDrag = { change, dragAmount ->
                        change.consume()
                        scope.launch {
                            dismissOffsetX.snapTo(dismissOffsetX.value + dragAmount)
                        }
                    },
                    onDragEnd = {
                        if ( kotlin.math.abs(dismissOffsetX.value) > 110f) {
                            haptic.performHapticFeedback(HapticFeedbackType.TextHandleMove)
                            onDismiss()
                            scope.launch { dismissOffsetX.snapTo(0f) }
                        } else {
                            scope.launch {
                                dismissOffsetX.animateTo(
                                    targetValue = 0f,
                                    animationSpec = spring(stiffness = Spring.StiffnessMedium)
                                )
                            }
                        }
                    },
                    onDragCancel = {
                        scope.launch { dismissOffsetX.animateTo(0f) }
                    }
                )
            }
    ) {
        Row(
            modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Box(
                modifier = Modifier
                    .size(6.dp)
                    .clip(CircleShape)
                    .background(MaterialTheme.colorScheme.secondary)
            )
            Spacer(modifier = Modifier.width(6.dp))
            Text(
                text = combinedLine,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis,
                color = Color.White.copy(alpha = 0.90f),
                fontSize = 12.sp,
                fontWeight = FontWeight.Normal
            )
        }
    }
}

@Composable
private fun PopupMenuActionButton(
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    label: String,
    tint: Color = Color.White,
    onClick: () -> Unit
) {
    TextButton(onClick = onClick) {
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            Icon(
                imageVector = icon,
                contentDescription = label,
                tint = tint,
                modifier = Modifier.size(20.dp)
            )
            Spacer(modifier = Modifier.height(2.dp))
            Text(
                text = label,
                color = tint,
                fontSize = 11.sp,
                fontWeight = FontWeight.Medium
            )
        }
    }
}
