package com.niagaraclone.launcher.ui.components

import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.Spring
import androidx.compose.foundation.background
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.gestures.detectVerticalDragGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.hapticfeedback.HapticFeedbackType
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.onSizeChanged
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.platform.LocalHapticFeedback
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlin.math.exp
import kotlin.math.roundToInt

@Composable
fun WaveAlphabetScrollbar(
    letters: List<Char>,
    activeLetter: Char?,
    onLetterChanged: (Char?) -> Unit,
    modifier: Modifier = Modifier
) {
    val haptic = LocalHapticFeedback.current
    val density = LocalDensity.current

    var barHeightPx by remember { mutableFloatStateOf(1f) }
    var touchY by remember { mutableFloatStateOf(-1f) }
    var isDragging by remember { mutableStateOf(false) }

    val maxWaveBulgePx = with(density) { 58.dp.toPx() }
    val sigmaPx = with(density) { 46.dp.toPx() }
    val bubbleOffsetPx = with(density) { (-118).dp.toPx() }

    val dragProgress by animateFloatAsState(
        targetValue = if (isDragging) 1f else 0f,
        animationSpec = spring(
            dampingRatio = Spring.DampingRatioNoBouncy,
            stiffness = Spring.StiffnessMedium
        ),
        label = "waveProgress"
    )

    fun resolveLetterAtY(y: Float): Char {
        val count = letters.size.coerceAtLeast(1)
        val fraction = (y / barHeightPx.coerceAtLeast(1f)).coerceIn(0f, 0.9999f)
        val index = (fraction * count).toInt().coerceIn(0, count - 1)
        return letters[index]
    }

    fun updateSelection(y: Float) {
        touchY = y.coerceIn(0f, barHeightPx)
        val candidate = resolveLetterAtY(touchY)
        if (candidate != activeLetter) {
            haptic.performHapticFeedback(HapticFeedbackType.TextHandleMove)
            onLetterChanged(candidate)
        }
    }

    Box(
        modifier = modifier
            .fillMaxHeight()
            .width(56.dp),
        contentAlignment = Alignment.CenterEnd
    ) {
        // Floating preview bubble next to the wave crest
        if (isDragging && activeLetter != null && touchY >= 0f) {
            Box(
                contentAlignment = Alignment.Center,
                modifier = Modifier
                    .align(Alignment.TopEnd)
                    .offset {
                        IntOffset(
                            x = bubbleOffsetPx.roundToInt(),
                            y = (touchY - with(density) { 30.dp.toPx() }).roundToInt()
                        )
                    }
                    .size(58.dp)
                    .clip(CircleShape)
                    .background(MaterialTheme.colorScheme.surface.copy(alpha = 0.92f))
            ) {
                Text(
                    text = activeLetter.toString(),
                    color = MaterialTheme.colorScheme.primary,
                    fontSize = 26.sp,
                    fontWeight = FontWeight.Bold
                )
            }
        }

        Column(
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.SpaceEvenly,
            modifier = Modifier
                .fillMaxHeight()
                .width(40.dp)
                .padding(vertical = 36.dp)
                .onSizeChanged { size ->
                    barHeightPx = size.height.toFloat().coerceAtLeast(1f)
                }
                .pointerInput(letters) {
                    detectTapGestures(
                        onPress = { offset ->
                            isDragging = true
                            updateSelection(offset.y)
                            tryAwaitRelease()
                            isDragging = false
                            touchY = -1f
                            onLetterChanged(null)
                        }
                    )
                }
                .pointerInput(letters) {
                    detectVerticalDragGestures(
                        onDragStart = { offset ->
                            isDragging = true
                            updateSelection(offset.y)
                        },
                        onVerticalDrag = { change, _ ->
                            change.consume()
                            updateSelection(change.position.y)
                        },
                        onDragEnd = {
                            isDragging = false
                            touchY = -1f
                            onLetterChanged(null)
                        },
                        onDragCancel = {
                            isDragging = false
                            touchY = -1f
                            onLetterChanged(null)
                        }
                    )
                }
        ) {
            val total = letters.size.coerceAtLeast(1)
            letters.forEachIndexed { index, letter ->
                val itemCenterY = ((index + 0.5f) / total) * barHeightPx
                val dy = if (isDragging && touchY >= 0f) {
                    kotlin.math.abs(touchY - itemCenterY)
                } else {
                    Float.MAX_VALUE
                }

                // Gaussian wave displacement: exp(-dy^2 / (2 * sigma^2))
                val gaussian = if (dy < sigmaPx * 3.2f) {
                    exp(-(dy * dy) / (2f * sigmaPx * sigmaPx))
                } else {
                    0f
                }

                val displacementX = -maxWaveBulgePx * gaussian * dragProgress
                val scale = 1f + (0.68f * gaussian * dragProgress)
                val isCurrentActive = isDragging && letter == activeLetter

                Box(
                    contentAlignment = Alignment.Center,
                    modifier = Modifier
                        .offset { IntOffset(displacementX.roundToInt(), 0) }
                        .scale(scale)
                ) {
                    Text(
                        text = letter.toString(),
                        color = if (isCurrentActive) {
                            MaterialTheme.colorScheme.primary
                        } else {
                            Color.White.copy(alpha = (0.62f + 0.38f * gaussian).coerceIn(0.62f, 1f))
                        },
                        fontSize = 11.sp,
                        fontWeight = if (isCurrentActive) FontWeight.ExtraBold else FontWeight.SemiBold
                    )
                }
            }
        }
    }
}
