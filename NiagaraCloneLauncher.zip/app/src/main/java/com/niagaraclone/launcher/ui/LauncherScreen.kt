package com.niagaraclone.launcher.ui

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.background
import androidx.compose.foundation.gestures.detectVerticalDragGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.systemBars
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.windowInsetsPadding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.Apps
import androidx.compose.material.icons.outlined.Home
import androidx.compose.material.icons.outlined.Search
import androidx.compose.material.icons.outlined.Visibility
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.FilledTonalButton
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.niagaraclone.launcher.R
import com.niagaraclone.launcher.ui.components.AppRowWithSwipeMenu
import com.niagaraclone.launcher.ui.components.FuzzySearchOverlay
import com.niagaraclone.launcher.ui.components.HeaderClockBattery
import com.niagaraclone.launcher.ui.components.WaveAlphabetScrollbar
import com.niagaraclone.launcher.viewmodel.LauncherViewModel

@Composable
fun LauncherScreen(
    viewModel: LauncherViewModel,
    modifier: Modifier = Modifier
) {
    val uiState by viewModel.uiState.collectAsStateWithLifecycle()
    val listState = rememberLazyListState()
    var showSettingsDialog by remember { mutableStateOf(false) }

    // Intercept Back button on Home Launcher: close search or return from A-Z list to Favorites
    BackHandler(enabled = true) {
        when {
            uiState.isSearchOverlayOpen -> viewModel.setSearchOverlayVisible(false)
            uiState.isAllAppsMode -> viewModel.setAllAppsMode(false)
            else -> {
                // Stay on Home screen (launchers never finish on Back press)
            }
        }
    }

    // Smoothly scroll LazyColumn when user drags across the Wave Alphabet Scrollbar
    LaunchedEffect(uiState.activeScrollLetter) {
        val letter = uiState.activeScrollLetter ?: return@LaunchedEffect
        val targetIndex = uiState.letterStartIndexMap[letter]
        if (targetIndex != null) {
            listState.scrollToItem(targetIndex)
        }
    }

    Box(
        modifier = modifier
            .fillMaxSize()
            .background(
                Brush.verticalGradient(
                    colors = listOf(
                        Color.Black.copy(alpha = 0.25f),
                        Color.Black.copy(alpha = 0.48f)
                    )
                )
            )
            .windowInsetsPadding(WindowInsets.systemBars)
    ) {
        if (!uiState.isAllAppsMode) {
            // Minimalist One-Handed Home Mode: Top Clock/Date/Battery + Thumb-Reachable Favorites
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .pointerInput(Unit) {
                        var cumulativeDragY = 0f
                        detectVerticalDragGestures(
                            onDragStart = { cumulativeDragY = 0f },
                            onVerticalDrag = { _, dragAmount ->
                                cumulativeDragY += dragAmount
                                if (cumulativeDragY < -110f) {
                                    viewModel.setSearchOverlayVisible(true)
                                    cumulativeDragY = 0f
                                }
                            }
                        )
                    },
                verticalArrangement = Arrangement.SpaceBetween
            ) {
                HeaderClockBattery(
                    isNotificationAccessGranted = uiState.isNotificationAccessGranted,
                    onOpenNotificationAccess = viewModel::openNotificationListenerSettings,
                    onOpenLauncherSettingsDialog = { showSettingsDialog = true }
                )

                // Lower-Middle Ergonomic Thumb Zone for up to 8 Favorites
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .weight(1f),
                    verticalArrangement = Arrangement.Bottom
                ) {
                    if (uiState.favoriteApps.isEmpty() && !uiState.isLoading) {
                        Text(
                            text = stringResource(id = R.string.favorites_empty_hint),
                            color = Color.White.copy(alpha = 0.75f),
                            fontSize = 14.sp,
                            modifier = Modifier.padding(horizontal = 28.dp, vertical = 24.dp)
                        )
                    } else {
                        LazyColumn(
                            modifier = Modifier.fillMaxWidth(),
                            contentPadding = PaddingValues(bottom = 12.dp)
                        ) {
                            itemsIndexed(
                                items = uiState.favoriteApps,
                                key = { _, app -> "fav_${app.packageName}" }
                            ) { _, app ->
                                AppRowWithSwipeMenu(
                                    app = app,
                                    onLaunchApp = viewModel::launchApp,
                                    onOpenNotification = viewModel::openNotification,
                                    onDismissNotification = viewModel::dismissNotification,
                                    onToggleFavorite = viewModel::toggleFavorite,
                                    onToggleHidden = viewModel::toggleHidden,
                                    onOpenAppInfo = viewModel::openAppInfo,
                                    onRequestUninstall = viewModel::requestUninstall
                                )
                            }
                        }
                    }

                    // Bottom Ergonomic Search & All-Apps Pill Bar
                    BottomSearchAndModeBar(
                        isAllAppsMode = false,
                        onOpenSearch = { viewModel.setSearchOverlayVisible(true) },
                        onToggleAllApps = { viewModel.setAllAppsMode(true) }
                    )
                }
            }
        } else {
            // Full A-Z App List Mode (also triggered automatically when touching the Wave Scrollbar)
            Column(modifier = Modifier.fillMaxSize()) {
                LazyColumn(
                    state = listState,
                    modifier = Modifier
                        .fillMaxWidth()
                        .weight(1f),
                    contentPadding = PaddingValues(bottom = 16.dp)
                ) {
                    item(key = "all_apps_header") {
                        HeaderClockBattery(
                            isNotificationAccessGranted = uiState.isNotificationAccessGranted,
                            onOpenNotificationAccess = viewModel::openNotificationListenerSettings,
                            onOpenLauncherSettingsDialog = { showSettingsDialog = true }
                        )
                    }

                    itemsIndexed(
                        items = uiState.allVisibleApps,
                        key = { _, app -> "all_${app.packageName}" }
                    ) { index, app ->
                        val prevLetter = uiState.allVisibleApps.getOrNull(index - 1)?.firstLetter
                        if (index == 0 || prevLetter != app.firstLetter) {
                            Text(
                                text = app.firstLetter.toString(),
                                color = MaterialTheme.colorScheme.primary,
                                fontSize = 13.sp,
                                fontWeight = FontWeight.Bold,
                                modifier = Modifier.padding(start = 32.dp, top = 12.dp, bottom = 2.dp)
                            )
                        }

                        AppRowWithSwipeMenu(
                            app = app,
                            onLaunchApp = viewModel::launchApp,
                            onOpenNotification = viewModel::openNotification,
                            onDismissNotification = viewModel::dismissNotification,
                            onToggleFavorite = viewModel::toggleFavorite,
                            onToggleHidden = viewModel::toggleHidden,
                            onOpenAppInfo = viewModel::openAppInfo,
                            onRequestUninstall = viewModel::requestUninstall
                        )
                    }
                }

                BottomSearchAndModeBar(
                    isAllAppsMode = true,
                    onOpenSearch = { viewModel.setSearchOverlayVisible(true) },
                    onToggleAllApps = { viewModel.setAllAppsMode(false) }
                )
            }
        }

        // Right-Edge Signature "Wave" Alphabet Scrollbar (60fps/120fps)
        WaveAlphabetScrollbar(
            letters = uiState.availableLetters,
            activeLetter = uiState.activeScrollLetter,
            onLetterChanged = viewModel::setActiveScrollLetter,
            modifier = Modifier.align(Alignment.CenterEnd)
        )

        // Instant Fuzzy Search Overlay
        FuzzySearchOverlay(
            visible = uiState.isSearchOverlayOpen,
            query = uiState.searchQuery,
            results = uiState.searchResults,
            onQueryChange = viewModel::setSearchQuery,
            onClose = { viewModel.setSearchOverlayVisible(false) },
            onLaunchApp = viewModel::launchApp,
            onOpenNotification = viewModel::openNotification,
            onDismissNotification = viewModel::dismissNotification,
            onToggleFavorite = viewModel::toggleFavorite,
            onToggleHidden = viewModel::toggleHidden,
            onOpenAppInfo = viewModel::openAppInfo,
            onRequestUninstall = viewModel::requestUninstall
        )

        if (showSettingsDialog) {
            AlertDialog(
                onDismissRequest = { showSettingsDialog = false },
                title = { Text(text = "Launcher Options") },
                text = {
                    Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                        FilledTonalButton(
                            onClick = {
                                showSettingsDialog = false
                                viewModel.openSystemDefaultLauncherSettings()
                            },
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Icon(imageVector = Icons.Outlined.Home, contentDescription = null)
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(text = "Set as Default Home App")
                        }

                        FilledTonalButton(
                            onClick = {
                                showSettingsDialog = false
                                viewModel.openNotificationListenerSettings()
                            },
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Text(text = "Notification Access Settings")
                        }

                        if (uiState.hiddenApps.isNotEmpty()) {
                            Button(
                                onClick = {
                                    viewModel.unhideAllApps()
                                    showSettingsDialog = false
                                },
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                Icon(imageVector = Icons.Outlined.Visibility, contentDescription = null)
                                Spacer(modifier = Modifier.width(8.dp))
                                Text(text = "Unhide All (${uiState.hiddenApps.size}) Apps")
                            }
                        }
                    }
                },
                confirmButton = {
                    TextButton(onClick = { showSettingsDialog = false }) {
                        Text(text = "Close")
                    }
                }
            )
        }
    }
}

@Composable
private fun BottomSearchAndModeBar(
    isAllAppsMode: Boolean,
    onOpenSearch: () -> Unit,
    onToggleAllApps: () -> Unit
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(start = 24.dp, end = 48.dp, top = 8.dp, bottom = 18.dp),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Surface(
            onClick = onOpenSearch,
            shape = RoundedCornerShape(28.dp),
            color = MaterialTheme.colorScheme.surface.copy(alpha = 0.78f),
            modifier = Modifier.weight(1f)
        ) {
            Row(
                modifier = Modifier.padding(horizontal = 18.dp, vertical = 12.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Icon(
                    imageVector = Icons.Outlined.Search,
                    contentDescription = "Search",
                    tint = MaterialTheme.colorScheme.primary,
                    modifier = Modifier.size(20.dp)
                )
                Spacer(modifier = Modifier.width(10.dp))
                Text(
                    text = "Search apps (or swipe up)",
                    color = Color.White.copy(alpha = 0.82f),
                    fontSize = 14.sp,
                    fontWeight = FontWeight.Medium
                )
            }
        }

        Spacer(modifier = Modifier.width(10.dp))

        Surface(
            onClick = onToggleAllApps,
            shape = RoundedCornerShape(28.dp),
            color = MaterialTheme.colorScheme.surface.copy(alpha = 0.78f)
        ) {
            Row(
                modifier = Modifier.padding(horizontal = 14.dp, vertical = 12.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Icon(
                    imageVector = if (isAllAppsMode) Icons.Outlined.Home else Icons.Outlined.Apps,
                    contentDescription = if (isAllAppsMode) "Favorites" else "All Apps",
                    tint = Color.White,
                    modifier = Modifier.size(20.dp)
                )
            }
        }
    }
}
