# Niagara Clone Minimalist Launcher (Android / Jetpack Compose)

An ultra-minimalist, one-handed Android Launcher inspired by Niagara Launcher, built with **100% Kotlin 2.1.0**, **Jetpack Compose (BOM 2025.02.00)**, **Material 3**, **Clean MVVM (`StateFlow`)**, and **Jetpack DataStore**.

## Key Features
1. **System Home & Live/Static Wallpaper Passthrough**: Configured with `CATEGORY_HOME`, `singleTask` launch mode, `enableEdgeToEdge()`, and `Theme.Translucent.NoTitleBar` + `windowShowWallpaper=true`.
2. **Ergonomic One-Handed Home Screen**: Live digital clock, date, and battery percentage header at the top; up to 8 pinned favorite apps in the lower-middle thumb zone.
3. **Signature 60fps/120fps "Wave" Alphabet Scrollbar**: Right-edge vertical `#` + `A–Z` bar with Gaussian horizontal wave displacement, active letter scaling, floating preview bubble, and `HapticFeedbackType.TextHandleMove` haptics.
4. **Inline Notification Previews**: `LauncherNotificationService` filters out ongoing/foreground service noise and renders single-line notification previews underneath matching apps with tap-to-open and horizontal swipe-to-dismiss.
5. **Swipe-Right / Long-Press App Pop-Up Menu**: Spring-animated card with **Pin/Unpin Favorite**, **Hide App**, **App Info**, and **Uninstall**.
6. **Instant Fuzzy Search**: Swipe up on the home screen or tap the bottom pill button to open an auto-focused fuzzy search overlay.

## How to Build the APK from Your Phone Browser (GitHub Actions)
1. Extract `NiagaraCloneLauncher.zip` on your phone (or upload the extracted files directly to a new GitHub repository on the `main` branch).
   - *Tip for Phone Browsers*: If your phone browser makes uploading nested folders tricky, you can simply upload `.github/workflows/build-apk.yml` into `.github/workflows/build-apk.yml` and upload `NiagaraCloneLauncher.zip` itself into the repository root — the workflow automatically detects and unzips `NiagaraCloneLauncher.zip` before compiling!
2. Open the **Actions** tab in your GitHub repository, select **Build Android Debug APK**, and tap **Run workflow** (or let it trigger automatically on push to `main`).
3. Once the workflow finishes (~2–3 minutes), scroll down to **Artifacts** on the workflow run summary page and download **`NiagaraCloneLauncher-debug-apk`**.
